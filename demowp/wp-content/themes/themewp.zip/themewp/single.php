    <?php get_header(); ?>


     <h1><?php echo excerpt(the_title());?></h1>
 
                     
     <div>
 <?php
$content = get_the_content('Read more');
print $content;
?>
     </div>
            
     <?php get_footer(); ?>